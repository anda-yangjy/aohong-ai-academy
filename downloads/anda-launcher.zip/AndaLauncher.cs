using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Win32;

// Fixed-ID launcher, no shell commands, no URL-provided arguments or paths.
internal static class AndaLauncher {
  internal static readonly string Home=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"AndaTrainingLauncher");
  internal static readonly string ConfigFile=Path.Combine(Home,"apps.json");
  internal static readonly string InstalledExe=Path.Combine(Home,"AndaLauncher.exe");
  static readonly HashSet<string> Denied=new HashSet<string>(StringComparer.OrdinalIgnoreCase){"cmd","powershell","pwsh","wscript","cscript","mshta","rundll32","regsvr32","msiexec","regedit","reg","control","explorer","conhost","python","pythonw","node","csc","bash","wsl","wt","terminal","schtasks","wmic","certutil","bitsadmin","curl","ftp","sftp","ssh"};
  [STAThread] static int Main(string[] args) {
    Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
    try {
      if(args.Length==1 && args[0]=="--self-test") { SelfTest();return 0; }
      if(args.Length==0 || (args.Length==1 && args[0]=="--setup")) { Application.Run(new SetupForm());return 0; }
      if(args.Length!=1)throw new InvalidOperationException("无效的启动参数。");
      string project=ParseProjectId(args[0]);
      if(project!=null){OpenProject(project);return 0;}
      string id=ParseId(args[0]);var apps=ReadConfig();string path;
      if(!apps.TryGetValue(id,out path))throw new InvalidOperationException("尚未绑定工具 ID："+id+"。请先打开 AndaLauncher.exe 配置。");
      path=ValidatePath(path);
      Process.Start(new ProcessStartInfo{FileName=path,WorkingDirectory=Path.GetDirectoryName(path),UseShellExecute=false});return 0;
    } catch(Exception ex) {MessageBox.Show(ex.Message,"anda · 本机启动器",MessageBoxButtons.OK,MessageBoxIcon.Information);return 1;}
  }
  static readonly Dictionary<string,string> ProjectThreads=new Dictionary<string,string>(StringComparer.Ordinal){
    {"ai-radar","01a1cd60-6b52-7ed1-881d-ec36ce386944"},
    {"token-stats","01a1e497-6780-7a13-81b1-90f95604e955"},
    {"video-downloader","01a1ce43-912b-7670-9ffa-6a38cb9b8de1"},
    {"pdf-renamer","01a18666-f14c-71e1-97df-534914863703"}
  };
  internal static string ParseProjectId(string uri){var m=Regex.Match(uri??"",@"\Aanda-launch://project/(ai-radar|token-stats|video-downloader|pdf-renamer)/?\z",RegexOptions.CultureInvariant);return m.Success?m.Groups[1].Value:null;}
  internal static void OpenProject(string id){
    var errors=new List<string>();
    try {var apps=ReadConfig();string path;if(!apps.TryGetValue(id,out path))throw new InvalidOperationException("尚未在启动器中绑定 "+id);path=ValidatePath(path);Process.Start(new ProcessStartInfo{FileName=path,WorkingDirectory=Path.GetDirectoryName(path),UseShellExecute=false});}
    catch(Exception ex){errors.Add("本地程序未打开："+ex.Message);}
    try {Process.Start(new ProcessStartInfo{FileName="codex://threads/"+ProjectThreads[id],UseShellExecute=true});}
    catch(Exception ex){errors.Add("Codex 聊天未打开："+ex.Message);}
    if(errors.Count>0)MessageBox.Show(string.Join("\n\n",errors.ToArray())+"\n\n请检查启动器配置和 Codex 安装。","anda · 项目演示",MessageBoxButtons.OK,MessageBoxIcon.Information);
  }
  internal static string ParseId(string uri) {var m=Regex.Match(uri??"",@"\Aanda-launch://open/([a-z][a-z0-9-]{0,47})/?\z",RegexOptions.CultureInvariant);if(!m.Success)throw new InvalidOperationException("链接无效：仅允许 anda-launch://open/白名单ID，不接受路径、命令或参数。");return m.Groups[1].Value;}
  internal static string ValidatePath(string value) {if(string.IsNullOrWhiteSpace(value)||!Path.IsPathRooted(value)||value.StartsWith(@"\\")||value.IndexOfAny(new[]{'\r','\n','"','\0'})>=0)throw new InvalidOperationException("请选择本机磁盘上的完整 EXE 路径。");string full=Path.GetFullPath(value);if(!string.Equals(Path.GetExtension(full),".exe",StringComparison.OrdinalIgnoreCase)||Denied.Contains(Path.GetFileNameWithoutExtension(full)))throw new InvalidOperationException("只允许普通应用 EXE，不允许命令解释器、脚本宿主或系统管理工具。");if(!File.Exists(full))throw new FileNotFoundException("找不到应用文件："+full);return full;}
  internal static Dictionary<string,string> ReadConfig(){if(!File.Exists(ConfigFile))return new Dictionary<string,string>();return new JavaScriptSerializer().Deserialize<Dictionary<string,string>>(File.ReadAllText(ConfigFile,Encoding.UTF8))??new Dictionary<string,string>();}
  internal static void Install(Dictionary<string,string> apps) {
    foreach(var entry in apps){if(!Regex.IsMatch(entry.Key,@"\A[a-z][a-z0-9-]{0,47}\z"))throw new InvalidOperationException("白名单 ID 无效。");ValidatePath(entry.Value);}
    Directory.CreateDirectory(Home);string source=Application.ExecutablePath;
    if(!string.Equals(Path.GetFullPath(source),Path.GetFullPath(InstalledExe),StringComparison.OrdinalIgnoreCase))File.Copy(source,InstalledExe,true);
    string temp=ConfigFile+".tmp";File.WriteAllText(temp,new JavaScriptSerializer().Serialize(apps),Encoding.UTF8);
    if(File.Exists(ConfigFile))File.Replace(temp,ConfigFile,null);else File.Move(temp,ConfigFile);
    using(var key=Registry.CurrentUser.CreateSubKey(@"Software\Classes\anda-launch")){key.SetValue("","URL:anda Training Launcher");key.SetValue("URL Protocol","");using(var command=key.CreateSubKey(@"shell\open\command")){command.SetValue("","\""+InstalledExe+"\" \"%1\"");}}
  }
  static void SelfTest(){if(ParseProjectId("anda-launch://project/ai-radar")!="ai-radar"||ParseProjectId("anda-launch://project/ai-radar?x=1")!=null||ParseProjectId("anda-launch://project/unknown")!=null)throw new Exception("Project URL validation failed");if(ParseId("anda-launch://open/my-tool")!="my-tool")throw new Exception("Valid ID failed");string[] bad={"anda-launch://open/../cmd","anda-launch://open/my-tool?cmd=x","anda-launch://open/%63md","anda-launch://open/my-tool\" --setup","http://open/my-tool","anda-launch://open/my-tool/extra","anda-launch://open/","anda-launch://open/my-tool\n"};foreach(var s in bad){bool rejected=false;try{ParseId(s);}catch{rejected=true;}if(!rejected)throw new Exception("Unsafe URI accepted");}}
}
internal sealed class SetupForm:Form {
  DataGridView grid=new DataGridView(); Label status=new Label();
  internal SetupForm(){Text="anda · 安达 | 本机应用启动器配置";Width=870;Height=590;StartPosition=FormStartPosition.CenterScreen;BackColor=Color.FromArgb(17,27,35);ForeColor=Color.White;Font=new Font("Microsoft YaHei UI",10);
    var intro=new Label{Text="只绑定你信任的本机 EXE。网页仅传入 ID，不传入命令、路径或参数。\n点击安装只注册当前用户协议，无管理员权限、无后台服务；浏览器可能询问是否打开应用。",Dock=DockStyle.Top,Height=80,Padding=new Padding(20,14,20,0)};Controls.Add(intro);
    grid.Dock=DockStyle.Fill;grid.BackgroundColor=Color.FromArgb(25,40,49);grid.AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill;grid.RowHeadersVisible=false;grid.AllowUserToAddRows=true;grid.DefaultCellStyle.ForeColor=Color.Black;grid.DefaultCellStyle.BackColor=Color.White;grid.ColumnHeadersDefaultCellStyle.ForeColor=Color.Black;grid.Columns.Add("id","白名单 ID（小写字母、数字、短横线）");grid.Columns.Add("path","本机 EXE 完整路径");grid.Columns[0].FillWeight=38;grid.Columns[1].FillWeight=62;
    var body=new Panel{Dock=DockStyle.Fill,Padding=new Padding(18,5,18,5)};body.Controls.Add(grid);Controls.Add(body);body.BringToFront();
    var buttons=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=58,Padding=new Padding(15,8,0,0)};var browse=new Button{Text="选择 EXE → 当前行",AutoSize=true};browse.Click+=(s,e)=>Browse();var save=new Button{Text="安装 / 更新白名单",AutoSize=true};save.Click+=(s,e)=>Save();var folder=new Button{Text="打开配置目录",AutoSize=true};folder.Click+=(s,e)=>{if(Directory.Exists(AndaLauncher.Home))Process.Start(new ProcessStartInfo(AndaLauncher.Home){UseShellExecute=true});};var remove=new Button{Text="撤销协议注册",AutoSize=true};remove.Click+=(s,e)=>Unregister();buttons.Controls.Add(browse);buttons.Controls.Add(save);buttons.Controls.Add(folder);buttons.Controls.Add(remove);foreach(Control b in buttons.Controls){b.ForeColor=Color.Black;b.BackColor=Color.FromArgb(205,244,157);}Controls.Add(buttons);
    status.Dock=DockStyle.Bottom;status.Height=65;status.Padding=new Padding(18,6,18,5);status.ForeColor=Color.LightGreen;status.Text="给 EXE 设置固定 ID，例如 my-tool。网页工具卡填写同一个 ID。\n不要绑定命令行解释器或来源不明的程序。";Controls.Add(status);status.BringToFront();buttons.BringToFront();intro.BringToFront();
    try{var apps=AndaLauncher.ReadConfig();if(apps.Count==0){AddDefault(apps,"workbuddy",@"D:\Users\anda\AppData\Local\Programs\WorkBuddy\WorkBuddy.exe");AddDefault(apps,"deepseek",@"D:\deepseek\DeepSeek Harness.exe");}AddDefault(apps,"ai-radar",@"D:\AI\AI-Radar\release-summary\AI-Radar\AI-Radar.exe");AddDefault(apps,"token-stats",@"D:\AI\Codex Token统计工具\Codex Token统计工具.exe");AddDefault(apps,"video-downloader",@"D:\AI\VideoDownloader\视频下载助手.exe");AddDefault(apps,"pdf-renamer",@"D:\AI\凭证重命名工具\凭证PDF重命名工具_v2.4_免安装版\凭证PDF重命名工具_v2.4\凭证PDF重命名_v2.4.exe");foreach(var x in apps)grid.Rows.Add(x.Key,x.Value);}catch(Exception ex){status.Text="读取配置失败："+ex.Message;}
  }
  static void AddDefault(Dictionary<string,string> d,string id,string path){if(!d.ContainsKey(id)&&File.Exists(path))d[id]=path;}
  void Browse(){using(var picker=new OpenFileDialog{Filter="Windows 应用 (*.exe)|*.exe",CheckFileExists=true}){if(picker.ShowDialog()!=DialogResult.OK)return;int i=grid.CurrentCell==null?-1:grid.CurrentCell.RowIndex;if(i<0||grid.Rows[i].IsNewRow)i=grid.Rows.Add();grid.Rows[i].Cells[1].Value=picker.FileName;if(grid.Rows[i].Cells[0].Value==null)grid.Rows[i].Cells[0].Value="my-tool";}}
  void Save(){try{grid.EndEdit();var apps=new Dictionary<string,string>();foreach(DataGridViewRow row in grid.Rows){if(row.IsNewRow)continue;string id=Convert.ToString(row.Cells[0].Value).Trim(),path=Convert.ToString(row.Cells[1].Value).Trim();if(id.Length==0&&path.Length==0)continue;if(apps.ContainsKey(id))throw new InvalidOperationException("ID 重复："+id);apps.Add(id,path);}if(apps.Count==0)throw new InvalidOperationException("至少绑定一个工具。");AndaLauncher.Install(apps);status.Text="已安装并注册 anda-launch 协议。\n已绑定："+string.Join(", ",apps.Keys)+"。现在可回网页点击本地工具。";}catch(Exception ex){MessageBox.Show(ex.Message,"配置未保存",MessageBoxButtons.OK,MessageBoxIcon.Warning);}}
  void Unregister(){if(MessageBox.Show("撤销当前用户的 anda-launch 协议注册？不会删除应用或白名单配置。","撤销协议",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;try{Registry.CurrentUser.DeleteSubKeyTree(@"Software\Classes\anda-launch",false);status.Text="已撤销协议注册；白名单和程序保留，可随时重新安装。";}catch(Exception ex){status.Text="撤销失败："+ex.Message;}}
}
